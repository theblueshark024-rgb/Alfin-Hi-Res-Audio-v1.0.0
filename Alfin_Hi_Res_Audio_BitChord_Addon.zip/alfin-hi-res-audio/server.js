import http from "node:http";
import { URL } from "node:url";

const PORT = Number(process.env.PORT || 3000);
const IA = "https://archive.org";
const ALLOWED_LICENSES = [
  "creativecommons.org/publicdomain/",
  "creativecommons.org/licenses/",
  "creativecommons.org/publicdomain/zero/"
];

const manifest = JSON.parse(await (await import("node:fs/promises")).readFile(
  new URL("./manifest.json", import.meta.url), "utf8"
));

function send(res, status, body) {
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "access-control-allow-origin": "*",
    "cache-control": "no-store"
  });
  res.end(JSON.stringify(body));
}
function isAllowed(meta) {
  const license = String(meta.metadata?.licenseurl || meta.metadata?.license || "").toLowerCase();
  return ALLOWED_LICENSES.some(x => license.includes(x));
}
function chooseAudio(meta, quality) {
  const files = (meta.files || []).filter(f =>
    f.name && !f.name.endsWith("_meta.xml") && !f.name.endsWith("_files.xml")
  );
  const audio = files.filter(f => /\.(flac|wav|aiff|alac|m4a|mp3|ogg|opus)$/i.test(f.name));
  const rank = name => {
    const n = name.toLowerCase();
    if (n.endsWith(".flac")) return 0;
    if (n.endsWith(".wav") || n.endsWith(".aiff")) return 1;
    if (n.endsWith(".alac") || n.endsWith(".m4a")) return 2;
    if (n.endsWith(".ogg") || n.endsWith(".opus")) return 3;
    return 4;
  };
  audio.sort((a,b) => rank(a.name)-rank(b.name));
  if (quality === "high") return audio.find(f => /\.(mp3|m4a|ogg|opus)$/i.test(f.name)) || audio[0];
  return audio[0];
}
async function getJSON(url) {
  const r = await fetch(url, { headers: { "user-agent": "AlfinHiResAudio/1.0 (BitChord addon)" } });
  if (!r.ok) throw new Error(`Upstream returned ${r.status}`);
  return r.json();
}
async function search(q, quality) {
  const params = new URLSearchParams({
    q: `mediatype:audio AND (${q.trim().split(/\s+/).map(w => `title:"${w.replaceAll('"',"")}" OR creator:"${w.replaceAll('"',"")}"`).join(" AND ")})`,
    fl: "identifier,title,creator",
    rows: "30",
    page: "1",
    output: "json"
  });
  const data = await getJSON(`${IA}/advancedsearch.php?${params}`);
  const docs = data.response?.docs || [];
  const results = [];
  for (const doc of docs.slice(0, 20)) {
    try {
      const meta = await getJSON(`${IA}/metadata/${encodeURIComponent(doc.identifier)}`);
      if (!isAllowed(meta)) continue;
      const file = chooseAudio(meta, quality);
      if (!file) continue;
      const md = meta.metadata || {};
      results.push({
        id: `${doc.identifier}::${file.name}`,
        title: String(md.title || doc.title || doc.identifier),
        artist: String(md.creator || doc.creator || "Unknown artist"),
        album: String(md.album || "Internet Archive"),
        duration: Number(file.length || 0),
        artworkURL: `${IA}/services/img/${encodeURIComponent(doc.identifier)}`,
        format: file.name.split(".").pop().toLowerCase(),
        audioQuality: file.name.toLowerCase().endsWith(".flac") ? "LOSSLESS" : "HIGH"
      });
    } catch { /* Skip unavailable or malformed catalogue entries. */ }
    if (results.length >= 12) break;
  }
  return results;
}
async function stream(id, quality) {
  const split = id.indexOf("::");
  if (split < 1) return null;
  const identifier = id.slice(0, split);
  const wanted = id.slice(split + 2);
  const meta = await getJSON(`${IA}/metadata/${encodeURIComponent(identifier)}`);
  if (!isAllowed(meta)) return null;
  const file = (meta.files || []).find(f => f.name === wanted);
  if (!file || !/\.(flac|wav|aiff|alac|m4a|mp3|ogg|opus)$/i.test(file.name)) return null;
  const ext = file.name.split(".").pop().toLowerCase();
  const codec = ext === "m4a" ? "alac" : ext;
  const url = `${IA}/download/${encodeURIComponent(identifier)}/${file.name.split("/").map(encodeURIComponent).join("/")}`;
  return {
    url, format: ext, codec, container: ext, manifest: "none", encrypted: false,
    quality: ext === "flac" || ext === "wav" || ext === "aiff" ? "Lossless · source metadata dependent" : "High quality · source metadata dependent",
    bitrate: file.bitrate ? Number(file.bitrate) : undefined,
    sampleRate: file.sample_rate ? Number(file.sample_rate) : undefined,
    bitDepth: file.bit_depth ? Number(file.bit_depth) : undefined
  };
}
const server = http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, `http://${req.headers.host || "localhost"}`);
    if (req.method !== "GET") return send(res, 405, { error: "GET only" });
    if (u.pathname === "/manifest.json") return send(res, 200, manifest);
    if (u.pathname === "/search") {
      const q = (u.searchParams.get("q") || "").trim();
      if (!q) return send(res, 200, { tracks: [] });
      const tracks = await search(q, u.searchParams.get("quality") || "max");
      return send(res, 200, { tracks });
    }
    if (u.pathname.startsWith("/stream/")) {
      const id = decodeURIComponent(u.pathname.slice("/stream/".length));
      const item = await stream(id, u.searchParams.get("quality") || "max");
      return item ? send(res, 200, item) : send(res, 404, { error: "No openly licensed audio rendition found" });
    }
    return send(res, 404, { error: "Not found" });
  } catch (e) {
    return send(res, 502, { error: "Catalogue temporarily unavailable", detail: e.message });
  }
});
server.listen(PORT, "0.0.0.0", () => console.log(`Alfin Hi-Res Audio listening on ${PORT}`));
