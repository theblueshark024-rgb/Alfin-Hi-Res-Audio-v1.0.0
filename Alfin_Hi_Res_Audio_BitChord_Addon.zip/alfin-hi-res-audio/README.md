# Alfin Hi-Res Audio

BitChord-compatible HTTP addon skeleton with a working Internet Archive catalogue adapter.
It searches only records whose metadata declares a Creative Commons or public-domain license.
This is a community project template, not a hosted service: you must deploy it to an HTTPS host.

## Requirements
- Node.js 20+
- A hosting account that can deploy a Node web service (Render, Railway, Fly.io, or your own server)

## Run locally
```bash
npm start
```
Then check:
- `http://localhost:3000/manifest.json`
- `http://localhost:3000/search?q=beethoven&quality=max`

## Deploy on Render
1. Create a Git repository and upload the contents of this folder.
2. In Render, create a new Web Service from that repository.
3. Render can detect `render.yaml`; use Node runtime.
4. After deployment, copy the HTTPS service URL.
5. In BitChord: Settings → Sources → Add an addon; paste the service root URL (or `/manifest.json`).

## Important limitations
- This is a deployable starter implementation, not a pre-hosted public URL.
- It uses Internet Archive metadata and direct file URLs, and intentionally filters to records whose metadata declares a Creative Commons or public-domain license. Metadata quality and rights declarations can be incomplete; check the item license before use.
- Hi-Res is returned only when the source file is actually available in a suitable format. The adapter does not invent 24-bit/192 kHz metadata or upsample audio.
- The adapter currently prioritizes FLAC, WAV and other lossless file extensions. It does not guarantee every WAV/FLAC is true high-resolution; the source file metadata must be inspected.
- `bitchordAuth` is not enabled in this starter. BitChord 1.9.1+ may mark it as outdated. Before production, implement the official BitChord addon-auth verifier and configure the exact deployed hostname as described in the official developer documentation.
- Do not add credentials for commercial streaming services or bypass DRM. This project only returns openly licensed, directly playable files.
- Internet Archive availability, rate limits, file formats, and metadata can change.

## Endpoint contract
- `GET /manifest.json`
- `GET /search?q=...&quality=max|hires|lossless|high` → `{ "tracks": [...] }`
- `GET /stream/{encoded-track-id}?quality=...` → direct media URL plus codec/container details

Official BitChord addon developer documentation:
https://bitchord.kushagrasingh.in/docs
